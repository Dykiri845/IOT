import time
import random
import urllib.request
import json
from datetime import datetime, timedelta, timezone
from influxdb_client import InfluxDBClient, Point, WritePrecision
from influxdb_client.client.write_api import SYNCHRONOUS

# ==========================================
# CREDENCIALES INFLUXDB CLOUD Y BLYNK
# ==========================================
INFLUX_URL = "https://us-east-1-1.aws.cloud2.influxdata.com"
INFLUX_TOKEN = "EkSaO2mgeX4hXomvrJl2sDEANshilMbVpJXBYjECKchpmE9LMyZbIuGdG0q1cKkWfCPW3vZlh4sfN-T8Q592Ew=="
INFLUX_ORG = "Alarma Anti-Incendios"
INFLUX_BUCKET = "monitoreo_aulas"

BLYNK_TOKEN = "UtYj3HhSHoIrAXDtISwUVzEYqyDhH0ex"
BLYNK_SERVER = "blynk.cloud"

client = InfluxDBClient(url=INFLUX_URL, token=INFLUX_TOKEN, org=INFLUX_ORG)
write_api = client.write_api(write_options=SYNCHRONOUS)

def cargar_historico_7_dias():
    print("1. Generando y migrando 7 días de datos históricos (168 horas x 2 aulas)...")
    puntos = []
    ahora = datetime.now(timezone.utc)

    for aula in ["Aula_201", "Aula_202"]:
        offset_aula = 0.0 if aula == "Aula_201" else -2.2
        for horas_atras in range(168, 0, -1):
            tiempo = ahora - timedelta(hours=horas_atras)
            hora_local = (tiempo - timedelta(hours=5)).hour  # Hora Colombia (UTC-5)

            # Simulación realista de ciclo día/noche en Bucaramanga/Girón
            if 6 <= hora_local <= 11:
                temp_base = random.uniform(29.5, 31.8) + offset_aula
                lum_base = random.uniform(420.0, 750.0)
            elif 12 <= hora_local <= 18:
                temp_base = random.uniform(25.2, 27.1) + offset_aula
                lum_base = random.uniform(35.0, 120.0)
            else:
                temp_base = random.uniform(25.3, 27.2) + offset_aula
                lum_base = random.uniform(15.0, 70.0)

            hum_base = round(random.uniform(62.0, 74.0), 1)
            punto = (
                Point("ambiente_aula")
                .tag("aula", aula)
                .field("temperatura", round(temp_base, 2))
                .field("humedad", hum_base)
                .field("luminosidad", round(lum_base, 1))
                .field("calor_alerta", 0)
                .time(tiempo, WritePrecision.S)
            )
            puntos.append(punto)

    write_api.write(bucket=INFLUX_BUCKET, org=INFLUX_ORG, record=puntos)
    print(f"[OK] Se insertaron {len(puntos)} registros históricos en '{INFLUX_BUCKET}'.\n")

def leer_blynk_tiempo_real(muestras=10):
    print(f"2. Capturando {muestras} lecturas en vivo desde ESP32 (Blynk Cloud)...")
    url = f"https://{BLYNK_SERVER}/external/api/get?token={BLYNK_TOKEN}&V0&V1&V2"

    for i in range(1, muestras + 1):
        try:
            with urllib.request.urlopen(url, timeout=3) as resp:
                if resp.status == 200:
                    datos = json.loads(resp.read().decode("utf-8"))
                    temp = round(float(datos["V0"]), 2)
                    hum = round(float(datos["V1"]), 1)
                    calor = int(datos["V2"])
                    lum = 950.0 if calor == 1 else 520.0

                    punto = (
                        Point("ambiente_aula")
                        .tag("aula", "Aula_201")
                        .field("temperatura", temp)
                        .field("humedad", hum)
                        .field("luminosidad", lum)
                        .field("calor_alerta", calor)
                        .time(datetime.now(timezone.utc), WritePrecision.S)
                    )
                    write_api.write(bucket=INFLUX_BUCKET, org=INFLUX_ORG, record=punto)
                    print(f"  [{i}/{muestras}] ESP32 -> Temp: {temp}°C | Hum: {hum}% | Calor: {calor} -> Guardado en InfluxDB")
        except Exception as e:
            print(f"  [{i}/{muestras}] Error leyendo Blynk: {e}")

        if i < muestras:
            time.sleep(2)

if __name__ == "__main__":
    cargar_historico_7_dias()
    leer_blynk_tiempo_real(muestras=10)
    client.close()
    print("\n[FINALIZADO] Ingesta histórica y telemetría inicial completadas.")