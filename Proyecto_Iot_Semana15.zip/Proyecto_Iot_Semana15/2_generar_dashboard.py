import pandas as pd
import plotly.graph_objects as go
from plotly.subplots import make_subplots
from influxdb_client import InfluxDBClient

# ==========================================
# CREDENCIALES INFLUXDB CLOUD
# ==========================================
INFLUX_URL = "https://us-east-1-1.aws.cloud2.influxdata.com"
INFLUX_TOKEN = "EkSaO2mgeX4hXomvrJl2sDEANshilMbVpJXBYjECKchpmE9LMyZbIuGdG0q1cKkWfCPW3vZlh4sfN-T8Q592Ew=="
INFLUX_ORG = "Alarma Anti-Incendios"
INFLUX_BUCKET = "monitoreo_aulas"

def obtener_datos_influx():
    client = InfluxDBClient(url=INFLUX_URL, token=INFLUX_TOKEN, org=INFLUX_ORG)
    query_api = client.query_api()
    
    query = f'''
    from(bucket: "{INFLUX_BUCKET}")
      |> range(start: -7d)
      |> filter(fn: (r) => r["_measurement"] == "ambiente_aula")
      |> pivot(rowKey:["_time"], columnKey: ["_field"], valueColumn: "_value")
    '''
    df = query_api.query_data_frame(query)
    client.close()
    
    if isinstance(df, list):
        df = pd.concat(df, ignore_index=True)
        
    df["_time"] = pd.to_datetime(df["_time"]).dt.tz_convert("America/Bogota")
    df = df.sort_values("_time")
    return df

def generar_html_dashboard():
    print("Consultando datos desde InfluxDB Cloud...")
    df = obtener_datos_influx()
    
    df_201 = df[df["aula"] == "Aula_201"].copy()
    df_202 = df[df["aula"] == "Aula_202"].copy()
    
    # Filtrar últimas 24 horas para Panel 1 y Panel 2
    limite_24h = df["_time"].max() - pd.Timedelta(hours=24)
    df_201_24h = df_201[df_201["_time"] >= limite_24h]
    df_202_24h = df_202[df_202["_time"] >= limite_24h]
    
    # Cálculo de umbral dinámico (Media + 2 * Desviación Estándar)
    media_t = df_201["temperatura"].mean()
    std_t = df_201["temperatura"].std()
    umbral_dinamico = round(media_t + (2 * std_t), 2)
    temp_actual_201 = round(df_201["temperatura"].iloc[-1], 2)
    temp_actual_202 = round(df_202["temperatura"].iloc[-1], 2)
    
    # Agregaciones diarias de los últimos 7 días (Panel 3)
    df["fecha"] = df["_time"].dt.strftime("%Y-%m-%d")
    resumen_diario = (
        df.groupby(["fecha", "aula"])["temperatura"]
        .agg(Promedio="mean", Maxima="max", Minima="min")
        .reset_index()
        .sort_values(["fecha", "aula"], ascending=[False, True])
    )
    resumen_diario["Promedio"] = resumen_diario["Promedio"].round(2)
    resumen_diario["Maxima"] = resumen_diario["Maxima"].round(2)
    resumen_diario["Minima"] = resumen_diario["Minima"].round(2)

    # Crear grilla 2x2 para los 4 paneles
    fig = make_subplots(
        rows=2, cols=2,
        subplot_titles=(
            "1. Tendencia Temp. y Luminosidad (Últimas 24h)",
            "2. Comparativa de Temperatura: Aula 201 vs Aula 202",
            "3. Agregaciones Diarias (Últimos 7 Días)",
            f"4. Estado Actual vs Umbral Dinámico ({umbral_dinamico} °C)"
        ),
        specs=[
            [{"secondary_y": True}, {"type": "scatter"}],
            [{"type": "table"}, {"type": "indicator"}]
        ],
        vertical_spacing=0.16,
        horizontal_spacing=0.10
    )

    # PANEL 1: Temperatura y Luminosidad 24h (Traces 0, 1 para Aula 201 y 2, 3 para Aula 202)
    fig.add_trace(
        go.Scatter(x=df_201_24h["_time"], y=df_201_24h["temperatura"], name="Temp Aula_201 (°C)", line=dict(color="#ef4444", width=2.5)),
        row=1, col=1, secondary_y=False
    )
    fig.add_trace(
        go.Scatter(x=df_201_24h["_time"], y=df_201_24h["luminosidad"], name="Luminosidad Aula_201 (lux)", line=dict(color="#f59e0b", dash="dot")),
        row=1, col=1, secondary_y=True
    )
    fig.add_trace(
        go.Scatter(x=df_202_24h["_time"], y=df_202_24h["temperatura"], name="Temp Aula_202 (°C)", line=dict(color="#3b82f6", width=2.5), visible=False),
        row=1, col=1, secondary_y=False
    )
    fig.add_trace(
        go.Scatter(x=df_202_24h["_time"], y=df_202_24h["luminosidad"], name="Luminosidad Aula_202 (lux)", line=dict(color="#10b981", dash="dot"), visible=False),
        row=1, col=1, secondary_y=True
    )

    # PANEL 2: Comparativa de Temperatura entre 2 Aulas (Traces 4 y 5)
    fig.add_trace(
        go.Scatter(x=df_201_24h["_time"], y=df_201_24h["temperatura"], name="Aula 201 (°C)", line=dict(color="#dc2626", width=2.5)),
        row=1, col=2
    )
    fig.add_trace(
        go.Scatter(x=df_202_24h["_time"], y=df_202_24h["temperatura"], name="Aula 202 (°C)", line=dict(color="#2563eb", width=2.5)),
        row=1, col=2
    )

    # PANEL 3: Tabla de Agregaciones Diarias (Trace 6)
    fig.add_trace(
        go.Table(
            header=dict(
                values=["<b>Fecha</b>", "<b>Aula</b>", "<b>Promedio (°C)</b>", "<b>Máxima (°C)</b>", "<b>Mínima (°C)</b>"],
                fill_color="#1e293b", font=dict(color="white", size=12), align="center"
            ),
            cells=dict(
                values=[
                    resumen_diario["fecha"], resumen_diario["aula"],
                    resumen_diario["Promedio"], resumen_diario["Maxima"], resumen_diario["Minima"]
                ],
                fill_color="#f8fafc", font=dict(color="#0f172a", size=11), align="center"
            )
        ),
        row=2, col=1
    )

    # PANEL 4: Gauge con Umbral Dinámico (Traces 7 y 8)
    fig.add_trace(
        go.Indicator(
            mode="gauge+number+delta",
            value=temp_actual_201,
            delta={"reference": umbral_dinamico, "increasing": {"color": "red"}, "decreasing": {"color": "green"}},
            title={"text": f"Aula 201 | Umbral: {umbral_dinamico}°C"},
            gauge={
                "axis": {"range": [15, 50]},
                "bar": {"color": "#1e293b"},
                "steps": [
                    {"range": [15, media_t + std_t], "color": "#22c55e"},          # Verde: Normal
                    {"range": [media_t + std_t, umbral_dinamico], "color": "#eab308"}, # Amarillo: Precaución
                    {"range": [umbral_dinamico, 50], "color": "#ef4444"}           # Rojo: Anomalía crítica
                ],
                "threshold": {"line": {"color": "black", "width": 4}, "thickness": 0.75, "value": umbral_dinamico}
            }
        ),
        row=2, col=2
    )
    fig.add_trace(
        go.Indicator(
            mode="gauge+number+delta",
            value=temp_actual_202,
            delta={"reference": umbral_dinamico},
            title={"text": f"Aula 202 | Umbral: {umbral_dinamico}°C"},
            visible=False,
            gauge={
                "axis": {"range": [15, 50]},
                "bar": {"color": "#1e293b"},
                "steps": [
                    {"range": [15, media_t + std_t], "color": "#22c55e"},
                    {"range": [media_t + std_t, umbral_dinamico], "color": "#eab308"},
                    {"range": [umbral_dinamico, 50], "color": "#ef4444"}
                ],
                "threshold": {"line": {"color": "black", "width": 4}, "thickness": 0.75, "value": umbral_dinamico}
            }
        ),
        row=2, col=2
    )

    # Selector interactivo de Aula (Variable de Dashboard)
    fig.update_layout(
        title_text="<b>Sistema IoT Monitoreo Ambiental UTS - Dashboard Consolidado (Semana 15)</b>",
        height=820,
        template="plotly_white",
        updatemenus=[
            dict(
                buttons=[
                    dict(
                        label="Seleccionar: Aula_201 (Principal)",
                        method="update",
                        args=[{"visible": [True, True, False, False, True, True, True, True, False]}]
                    ),
                    dict(
                        label="Seleccionar: Aula_202 (Comparativa)",
                        method="update",
                        args=[{"visible": [False, False, True, True, True, True, True, False, True]}]
                    )
                ],
                direction="down",
                showactive=True,
                x=0.82,
                y=1.08
            )
        ]
    )

    archivo_salida = "dashboard_iot_semana15.html"
    fig.write_html(archivo_salida)
    print(f"[OK] Dashboard generado exitosamente: {archivo_salida}")
    print(f"     Temperatura actual Aula 201: {temp_actual_201}°C | Umbral dinámico (μ + 2σ): {umbral_dinamico}°C")

if __name__ == "__main__":
    generar_html_dashboard()