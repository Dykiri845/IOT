from datetime import datetime, timezone
import pandas as pd
from influxdb_client import InfluxDBClient, Point, WritePrecision
from influxdb_client.client.write_api import SYNCHRONOUS

# ==========================================
# CREDENCIALES INFLUXDB CLOUD
# ==========================================
INFLUX_URL = "https://us-east-1-1.aws.cloud2.influxdata.com"
INFLUX_TOKEN = "EkSaO2mgeX4hXomvrJl2sDEANshilMbVpJXBYjECKchpmE9LMyZbIuGdG0q1cKkWfCPW3vZlh4sfN-T8Q592Ew=="
INFLUX_ORG = "Alarma Anti-Incendios"
INFLUX_BUCKET = "monitoreo_aulas"

client = InfluxDBClient(url=INFLUX_URL, token=INFLUX_TOKEN, org=INFLUX_ORG)
query_api = client.query_api()
write_api = client.write_api(write_options=SYNCHRONOUS)

def calcular_umbral_dinamico(aula="Aula_201"):
    query = f'''
    from(bucket: "{INFLUX_BUCKET}")
      |> range(start: -7d)
      |> filter(fn: (r) => r["_measurement"] == "ambiente_aula")
      |> filter(fn: (r) => r["aula"] == "{aula}")
      |> filter(fn: (r) => r["_field"] == "temperatura")
    '''
    df = query_api.query_data_frame(query)
    if isinstance(df, list):
        df = pd.concat(df, ignore_index=True)
        
    media = df["_value"].mean()
    desviacion = df["_value"].std()
    umbral = media + (2 * desviacion)
    return round(media, 2), round(desviacion, 2), round(umbral, 2)

def inyectar_anomalia(aula="Aula_201", temp_anomala=46.8):
    print(f"\n[SIMULACIÓN] Inyectando lectura anómala de {temp_anomala}°C en {aula} hacia InfluxDB Cloud...")
    punto_anomalo = (
        Point("ambiente_aula")
        .tag("aula", aula)
        .field("temperatura", float(temp_anomala))
        .field("humedad", 28.5)
        .field("luminosidad", 980.0)
        .field("calor_alerta", 1)
        .time(datetime.now(timezone.utc), WritePrecision.S)
    )
    write_api.write(bucket=INFLUX_BUCKET, org=INFLUX_ORG, record=punto_anomalo)
    print("[OK] Anomalía escrita en InfluxDB Cloud.")

def evaluar_y_alertar():
    media, std, umbral = calcular_umbral_dinamico("Aula_201")
    print("============================================================")
    print("   MOTOR DE ALERTAS DINÁMICAS IoT - INFLUXDB CLOUD (UTS)")
    print("============================================================")
    print(f"Histórico Aula_201 -> Media (μ): {media}°C | Desv. Estándar (σ): {std}°C")
    print(f"Umbral Dinámico Calculado (μ + 2σ): {umbral}°C")
    
    # Inyectar pico de temperatura para probar el disparo de alerta
    lectura_critica = 46.8
    inyectar_anomalia("Aula_201", lectura_critica)
    
    if lectura_critica > umbral:
        ahora_local = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        mensaje_alerta = (
            f"\n🚨 [ALERTA CRÍTICA DISPARADA] {ahora_local}\n"
            f"   Ubicación: Aula_201 (Sensor DHT11 / LM393)\n"
            f"   Temperatura Detectada: {lectura_critica}°C (Supera umbral dinámico de {umbral}°C en +{round(lectura_critica - umbral, 2)}°C)\n"
            f"   Acción: Notificación registrada en log y dashboard actualizado a estado ROJO.\n"
        )
        print(mensaje_alerta)
        with open("registro_alertas.log", "a", encoding="utf-8") as f:
            f.write(mensaje_alerta)
        print("[OK] Evidencia guardada en 'registro_alertas.log'.")

if __name__ == "__main__":
    evaluar_y_alertar()
    client.close()