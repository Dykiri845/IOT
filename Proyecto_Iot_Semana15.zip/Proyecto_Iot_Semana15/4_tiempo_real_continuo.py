import time
import threading
import urllib.request
import json
from http.server import BaseHTTPRequestHandler, HTTPServer
from datetime import datetime, timezone
import pandas as pd
from influxdb_client import InfluxDBClient, Point, WritePrecision
from influxdb_client.client.write_api import SYNCHRONOUS

# ==========================================
# CREDENCIALES INFLUXDB CLOUD Y BLYNK
# ==========================================
INFLUX_URL = "https://us-east-1-1.aws.cloud2.influxdata.com"
INFLUX_TOKEN = "EkSaO2mgeX4hXomvrJl2sDEANshilMbVpJXBYjECKchpmE9LMyZbIuGdG0q1cKkWfCPW3vZlh4sfN-T8Q592Ew=="
INFLUX_ORG = "Alarma Anti-Incendios"
INFLUX_BUCKET = "monitoreo_aulas"

BLYNK_TOKEN = "UtYj3HhSHoIrAXDtISwUVzEYqyDhH0ex"
BLYNK_SERVER = "blynk.cloud"
PUERTO_WEB = 8050

client = InfluxDBClient(url=INFLUX_URL, token=INFLUX_TOKEN, org=INFLUX_ORG)
write_api = client.write_api(write_options=SYNCHRONOUS)
query_api = client.query_api()

# Estado en memoria para respuesta inmediata (< 10 ms)
estado_vivo = {
    "tiempos": [],
    "temperaturas": [],
    "luminosidades": [],
    "temp_actual": 30.0,
    "hum_actual": 70.0,
    "calor_actual": 0,
    "media": 27.5,
    "std": 2.2,
    "umbral": 32.0,
    "ultima_hora": "--:--:--",
    "conectado": False,
    "mensaje_estado": "Iniciando..."
}

def cargar_base_inicial():
    print("Cargando histórico base desde InfluxDB Cloud...")
    query = f'''
    from(bucket: "{INFLUX_BUCKET}")
      |> range(start: -24h)
      |> filter(fn: (r) => r["_measurement"] == "ambiente_aula")
      |> filter(fn: (r) => r["aula"] == "Aula_201")
      |> pivot(rowKey:["_time"], columnKey: ["_field"], valueColumn: "_value")
    '''
    df = query_api.query_data_frame(query)
    if isinstance(df, list):
        df = pd.concat(df, ignore_index=True)

    df["_time"] = pd.to_datetime(df["_time"]).dt.tz_convert("America/Bogota")
    df = df.sort_values("_time").tail(40)

    estado_vivo["tiempos"] = df["_time"].dt.strftime("%H:%M:%S").tolist()
    estado_vivo["temperaturas"] = [round(float(x), 2) for x in df["temperatura"].tolist()]
    estado_vivo["luminosidades"] = [round(float(x), 1) for x in df["luminosidad"].tolist()]

    media = df["temperatura"].mean()
    std = df["temperatura"].std() if len(df) > 1 else 1.5
    estado_vivo["media"] = round(float(media), 2)
    estado_vivo["std"] = round(float(std), 2)
    estado_vivo["umbral"] = round(float(media + 2 * std), 2)
    if estado_vivo["temperaturas"]:
        estado_vivo["temp_actual"] = estado_vivo["temperaturas"][-1]

def verificar_hardware_blynk():
    url_hw = f"https://{BLYNK_SERVER}/external/api/isHardwareConnected?token={BLYNK_TOKEN}"
    try:
        with urllib.request.urlopen(url_hw, timeout=1.5) as resp:
            return resp.read().decode("utf-8").strip().lower() == "true"
    except Exception:
        return False

def hilo_captura_blynk():
    contador_influx = 0
    while True:
        url = f"https://{BLYNK_SERVER}/external/api/get?token={BLYNK_TOKEN}&V0&V1&V2"
        try:
            hw_online = verificar_hardware_blynk()
            with urllib.request.urlopen(url, timeout=1.5) as resp:
                if resp.status == 200:
                    datos = json.loads(resp.read().decode("utf-8"))
                    temp = round(float(datos["V0"]), 2)
                    hum = round(float(datos["V1"]), 1)
                    calor = int(datos["V2"])
                    lum = 950.0 if calor == 1 else 520.0
                    ahora_local = datetime.now().strftime("%H:%M:%S")

                    estado_vivo["temp_actual"] = temp
                    estado_vivo["hum_actual"] = hum
                    estado_vivo["calor_actual"] = calor
                    estado_vivo["ultima_hora"] = ahora_local
                    estado_vivo["conectado"] = hw_online
                    estado_vivo["mensaje_estado"] = "ESP32 EN LÍNEA" if hw_online else "ESP32 DESCONECTADO (ÚLTIMO DATO BLYNK)"

                    estado_vivo["tiempos"].append(ahora_local)
                    estado_vivo["temperaturas"].append(temp)
                    estado_vivo["luminosidades"].append(lum)

                    if len(estado_vivo["tiempos"]) > 60:
                        estado_vivo["tiempos"].pop(0)
                        estado_vivo["temperaturas"].pop(0)
                        estado_vivo["luminosidades"].pop(0)

                    serie = pd.Series(estado_vivo["temperaturas"])
                    media = serie.mean()
                    std = serie.std() if len(serie) > 1 else 1.5
                    estado_vivo["media"] = round(float(media), 2)
                    estado_vivo["std"] = round(float(std), 2)
                    estado_vivo["umbral"] = round(float(media + 2 * std), 2)

                    print(f"[{ahora_local}] HW:{hw_online} | Temp:{temp}°C | Hum:{hum}% | Calor:{calor}")

                    contador_influx += 1
                    if contador_influx >= 3 and hw_online:
                        contador_influx = 0
                        punto = (
                            Point("ambiente_aula")
                            .tag("aula", "Aula_201")
                            .field("temperatura", temp)
                            .field("humedad", hum)
                            .field("luminosidad", lum)
                            .field("calor_alerta", calor)
                            .time(datetime.now(timezone.utc), WritePrecision.S)
                        )
                        write_api.write(bucket=INFLUX_BUCKET, org=INFLUX_ORG, record=punto)
        except Exception as e:
            estado_vivo["conectado"] = False
            estado_vivo["mensaje_estado"] = f"Error red: {e}"

        time.sleep(1.0)

HTML_INTERACTIVO = """<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Monitoreo IoT Tiempo Real - ESP32 UTS</title>
  <script src="https://cdn.plot.ly/plotly-2.35.2.min.js"></script>
  <style>
    body { font-family: 'Segoe UI', sans-serif; background: #0f172a; color: #f8fafc; margin: 0; padding: 16px; }
    .header { display: flex; justify-content: space-between; align-items: center; background: #1e293b; padding: 12px 20px; border-radius: 10px; margin-bottom: 16px; }
    .badge { padding: 6px 14px; border-radius: 20px; font-weight: bold; font-size: 14px; }
    .online { background: #16a34a; color: white; }
    .offline { background: #dc2626; color: white; }
    .grid { display: grid; grid-template-columns: 1.4fr 1fr; gap: 16px; }
    .card { background: #1e293b; border-radius: 10px; padding: 12px; box-shadow: 0 4px 12px rgba(0,0,0,0.3); }
    .kpis { display: grid; grid-template-columns: repeat(4, 1fr); gap: 12px; margin-bottom: 16px; }
    .kpi { background: #1e293b; padding: 14px; border-radius: 10px; text-align: center; }
    .kpi h3 { margin: 0; font-size: 13px; color: #94a3b8; }
    .kpi p { margin: 6px 0 0; font-size: 26px; font-weight: bold; }
  </style>
</head>
<body>
  <div class="header">
    <div>
      <h2 style="margin:0;">Sistema IoT Tiempo Real - Aula 201 (ESP32 + Blynk + InfluxDB)</h2>
      <small id="reloj" style="color:#94a3b8;">Sincronizando...</small>
    </div>
    <span id="estado-esp" class="badge offline">CONECTANDO...</span>
  </div>

  <div class="kpis">
    <div class="kpi"><h3>TEMPERATURA VIVO</h3><p id="kpi-temp" style="color:#38bdf8;">-- °C</p></div>
    <div class="kpi"><h3>HUMEDAD RELATIVA</h3><p id="kpi-hum" style="color:#34d399;">-- %</p></div>
    <div class="kpi"><h3>SENSOR CALOR (LM393)</h3><p id="kpi-calor" style="color:#fbbf24;">NORMAL</p></div>
    <div class="kpi"><h3>UMBRAL DINÁMICO (μ+2σ)</h3><p id="kpi-umbral" style="color:#f87171;">-- °C</p></div>
  </div>

  <div class="grid">
    <div class="card"><div id="grafica-linea" style="height:430px;"></div></div>
    <div class="card"><div id="grafica-gauge" style="height:430px;"></div></div>
  </div>

  <script>
    let inicializado = false;

    async function actualizarDashboard() {
      try {
        const res = await fetch('/datos?t=' + Date.now());
        const d = await res.json();

        document.getElementById('reloj').innerText = `Última actualización: ${d.ultima_hora} | Frecuencia: 1 Hz`;
        const badge = document.getElementById('estado-esp');
        badge.innerText = d.mensaje_estado;
        badge.className = 'badge ' + (d.conectado ? 'online' : 'offline');

        document.getElementById('kpi-temp').innerText = `${d.temp_actual} °C`;
        document.getElementById('kpi-hum').innerText = `${d.hum_actual} %`;
        document.getElementById('kpi-umbral').innerText = `${d.umbral} °C`;

        const kpiCalor = document.getElementById('kpi-calor');
        if (d.calor_actual === 1 || d.temp_actual > d.umbral) {
          kpiCalor.innerText = '🚨 ALERTA';
          kpiCalor.style.color = '#ef4444';
        } else {
          kpiCalor.innerText = 'NORMAL';
          kpiCalor.style.color = '#22c55e';
        }

        const umbralArray = Array(d.tiempos.length).fill(d.umbral);

        if (!inicializado) {
          Plotly.newPlot('grafica-linea', [
            { x: d.tiempos, y: d.temperaturas, name: 'Temperatura (°C)', type: 'scatter', mode: 'lines+markers', line: { color: '#ef4444', width: 3 } },
            { x: d.tiempos, y: umbralArray, name: 'Umbral Dinámico', type: 'scatter', mode: 'lines', line: { color: '#facc15', dash: 'dash', width: 2 } }
          ], {
            title: 'Telemetría Térmica en Vivo (1 Hz)',
            paper_bgcolor: '#1e293b', plot_bgcolor: '#0f172a', font: { color: '#f8fafc' },
            xaxis: { title: 'Hora Local' }, yaxis: { title: 'Temperatura (°C)' },
            margin: { t: 45, b: 40, l: 50, r: 20 }
          }, { responsive: true });

          Plotly.newPlot('grafica-gauge', [{
            type: 'indicator', mode: 'gauge+number+delta',
            value: d.temp_actual,
            delta: { reference: d.umbral, increasing: { color: '#ef4444' }, decreasing: { color: '#22c55e' } },
            title: { text: `Estado Crítico vs Umbral (${d.umbral}°C)` },
            gauge: {
              axis: { range: [15, 50] },
              bar: { color: '#f8fafc' },
              steps: [
                { range: [15, d.media + d.std], color: '#22c55e' },
                { range: [d.media + d.std, d.umbral], color: '#eab308' },
                { range: [d.umbral, 50], color: '#ef4444' }
              ],
              threshold: { line: { color: 'white', width: 4 }, thickness: 0.75, value: d.umbral }
            }
          }], {
            paper_bgcolor: '#1e293b', font: { color: '#f8fafc' },
            margin: { t: 60, b: 20, l: 30, r: 30 }
          }, { responsive: true });

          inicializado = true;
        } else {
          Plotly.restyle('grafica-linea', {
            x: [d.tiempos, d.tiempos],
            y: [d.temperaturas, umbralArray]
          }, [0, 1]);

          Plotly.restyle('grafica-gauge', {
            value: [d.temp_actual],
            'delta.reference': [d.umbral],
            'title.text': [`Estado Crítico vs Umbral (${d.umbral}°C)`]
          }, [0]);
        }
      } catch (e) {
        console.error("Error actualizando dashboard:", e);
      }
    }

    setInterval(actualizarDashboard, 1000);
    actualizarDashboard();
  </script>
</body>
</html>
"""

class ManejadorDashboard(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path.startswith("/datos"):
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Cache-Control", "no-store, no-cache, must-revalidate")
            self.end_headers()
            self.wfile.write(json.dumps(estado_vivo).encode("utf-8"))
        else:
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.end_headers()
            self.wfile.write(HTML_INTERACTIVO.encode("utf-8"))

    def log_message(self, format, *args):
        pass

if __name__ == "__main__":
    cargar_base_inicial()
    threading.Thread(target=hilo_captura_blynk, daemon=True).start()
    print(f"\n🚀 DASHBOARD EN TIEMPO REAL ACTIVO EN: http://localhost:{PUERTO_WEB}")
    print("Abre esa dirección en tu navegador. Presiona Ctrl + C para detener.\n")
    servidor = HTTPServer(("127.0.0.1", PUERTO_WEB), ManejadorDashboard)
    try:
        servidor.serve_forever()
    except KeyboardInterrupt:
        client.close()
        print("\nServidor detenido.")