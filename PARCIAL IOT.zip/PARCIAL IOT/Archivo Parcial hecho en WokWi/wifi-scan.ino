#include <DHT.h>

#define DHTPIN 4       
#define DHTTYPE DHT22  

DHT dht(DHTPIN, DHTTYPE);

const int ldrPin = 34;     
const int trigPin = 5;    
const int echoPin = 18;    

void setup() {
  Serial.begin(115200);
  dht.begin();
  
  pinMode(ldrPin, INPUT);
  pinMode(trigPin, OUTPUT);
  pinMode(echoPin, INPUT);
  
  Serial.println("Iniciando sistema de monitoreo ambiental...");
}

void loop() {
 
  float humedad = dht.readHumidity();
  float temperatura = dht.readTemperature();

  
  if (isnan(humedad) || isnan(temperatura)) {
    Serial.println("Error al leer el sensor DHT!");
    return;
  }

  
  int luz = analogRead(ldrPin);

  
  digitalWrite(trigPin, LOW);
  delayMicroseconds(2);
  digitalWrite(trigPin, HIGH);
  delayMicroseconds(10);
  digitalWrite(trigPin, LOW);
  
  long duracion = pulseIn(echoPin, HIGH);
  float distancia = duracion * 0.034 / 2;

  
  Serial.println("=== MONITOREO AULA ===");
  Serial.print("Temperatura: "); Serial.print(temperatura); Serial.println(" °C");
  Serial.print("Humedad: "); Serial.print(humedad); Serial.println(" %");
  Serial.print("Luz: "); Serial.println(luz);
  Serial.print("Distancia: "); Serial.print(distancia); Serial.println(" cm");
  
  
  if (distancia < 30) {
    Serial.println("Estado: Ocupado (distancia < 30 cm)");
  } else {
    Serial.println("Estado: Libre");
  }
  
  Serial.println();
  delay(2000); 
}