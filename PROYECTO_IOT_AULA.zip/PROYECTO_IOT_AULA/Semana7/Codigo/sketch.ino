#include <DHT.h>

// ==================== CONFIGURACIÓN ====================
#define DHT_PIN 4
#define DHT_TYPE DHT22
#define LDR_PIN 34

// ==================== Umbrales de alerta ====================
#define TEMP_MAX 28.0
#define TEMP_MIN 15.0
#define HUM_MIN 40.0
#define HUM_MAX 80.0
#define LUZ_MIN 500

// ==================== OBJETOS ====================
DHT dht(DHT_PIN, DHT_TYPE);

// ==================== VARIABLES ====================
unsigned long ultimoMuestreo = 0;
const unsigned long INTERVALO_MUESTREO = 2000; // 2 segundos

void setup() {
  Serial.begin(115200);
  delay(2000); 

  Serial.println(F("----------------------------------------"));
  Serial.println(F("       SISTEMA DE MONITOREO DE AULA"));
  Serial.println(F("     Semana 7 - Comunicación Serial"));
  Serial.println(F("----------------------------------------"));
  Serial.println();

  dht.begin();
  Serial.println(F("[OK] Sensor DHT22 inicializado"));
  Serial.println(F("[OK] Módulo LDR configurado en GPIO 34"));
  Serial.println();
  Serial.println(F("Iniciando lecturas en tabla..."));
  Serial.println(F("----------------------------------------"));
}

void loop() {
  if (millis() - ultimoMuestreo >= INTERVALO_MUESTREO) {
    ultimoMuestreo = millis();

    float temperatura = dht.readTemperature();
    float humedad = dht.readHumidity();
    int luminosidad = analogRead(LDR_PIN);

    // Validación para sensor desconectado
    if (isnan(temperatura) || isnan(humedad)) {
      Serial.println(F("[ERROR] Fallo al leer el sensor DHT22. Verifique las conexiones."));
      return;
    }

    // Cabecera de la tabla
    Serial.println(F("+-------------+-------------+-------------+"));
    Serial.println(F("| Variable    | Valor       | Estado      |"));
    Serial.println(F("+-------------+-------------+-------------+"));

    // --- Fila de Temperatura ---
    Serial.print(F("| Temp        | "));
    Serial.print(temperatura, 1);
    Serial.print(F(" °C     | "));
    if (temperatura > TEMP_MAX) {
      Serial.println(F("ALERTA (Alta) |"));
    } else if (temperatura < TEMP_MIN) {
      Serial.println(F("ALERTA (Baja) |"));
    } else {
      Serial.println(F("OK            |"));
    }

    // --- Fila de Humedad ---
    Serial.print(F("| Humedad     | "));
    Serial.print(humedad, 1);
    Serial.print(F(" %      | "));
    if (humedad > HUM_MAX) {
      Serial.println(F("ALERTA (Alta) |"));
    } else if (humedad < HUM_MIN) {
      Serial.println(F("ALERTA (Baja) |"));
    } else {
      Serial.println(F("OK            |"));
    }

    // --- Fila de Luminosidad ---
    Serial.print(F("| Luz         | "));
    Serial.print(luminosidad);
    Serial.print(F(" units   | "));
    if (luminosidad > LUZ_MIN) {
      Serial.println(F("INSUFICIENTE  |"));
    } else {
      Serial.println(F("OK           |"));
    }

    Serial.println(F("+-------------+-------------+-------------+"));
    
    // Detalle coqueto adicional fuera de la tabla en cada ciclo
    if (luminosidad <= LUZ_MIN) {
      Serial.println(F("[ALERTA]] ILUMINACION ESTABLE Y SUFICIENTE"));
    }
    
    Serial.println(); // Espacio en blanco para separar el siguiente registro
  }
}