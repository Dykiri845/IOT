#ifndef CONFIG_H
#define CONFIG_H

// ==========================================
// CONFIGURACIÓN DE BLYNK IOT
// ==========================================
#define BLYNK_TEMPLATE_ID   "TMPL2YN-F-M4Y"
#define BLYNK_TEMPLATE_NAME "Alarma"
#define BLYNK_AUTH_TOKEN    "UtYj3HhSHoIrAXDtISwUVzEYqyDhH0ex"

// ==========================================
// CONFIGURACIÓN RED WIFI (OPCIONAL / RESPALDO)
// Nota: WiFiManager gestiona esto dinámicamente, 
// pero se definen por si requieres IP/red estática.
// ==========================================
#define WIFI_SSID           "TU_RED_WIFI"
#define WIFI_PASS           "TU_CONTRASEÑA_WIFI"

#endif // CONFIG_H