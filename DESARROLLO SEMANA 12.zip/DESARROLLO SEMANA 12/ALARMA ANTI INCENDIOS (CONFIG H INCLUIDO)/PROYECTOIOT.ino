// ==========================================
// CREDENCIALES DIRECTAS DE BLYNK
// ==========================================
#define BLYNK_TEMPLATE_ID   "TMPL2YN-F-M4Y"
#define BLYNK_TEMPLATE_NAME "Alarma"
#define BLYNK_AUTH_TOKEN    "UtYj3HhSHoIrAXDtISwUVzEYqyDhH0ex"

#define BLYNK_PRINT Serial

#include <WiFi.h>
#include <WebServer.h>
#include <DNSServer.h>
#include <WiFiManager.h>      // Portal Cautivo
#include <BlynkSimpleEsp32.h> // Blynk para ESP32
#include <DHT.h>              // Sensor Temp/Hum
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SH110X.h>  // OLED SH1106

// ==========================================
// DEFINICIÓN DE PINES (GPIOs)
// ==========================================
#define DHTPIN          23
#define DHTTYPE         DHT11
#define SENSOR_CALOR    22
#define BOTON_PIN       17
#define LED_ROJO        18
#define LED_AMARILLO    19
#define LED_VERDE       21
#define BUZZER_PIN      16

// ==========================================
// OBJETOS GLOBALES Y VARIABLES
// ==========================================
DHT dht(DHTPIN, DHTTYPE);
BlynkTimer timer;

#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
#define OLED_RESET -1
Adafruit_SH1106G display = Adafruit_SH1106G(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET);

unsigned long lastOled = 0;
int vistaOled = 1;             
bool ultimoEstadoBoton = HIGH;
bool ultimoEstadoFuego = false;

// Prototipos
void enviarTelemetriaBlynk();
void actualizarPantalla(bool fuego, float temp, float hum);

void setup() {
  Serial.begin(115200);
  Wire.begin(4, 5); // SDA = GPIO4, SCL = GPIO5

  pinMode(SENSOR_CALOR, INPUT);
  pinMode(BOTON_PIN, INPUT_PULLUP);
  pinMode(LED_ROJO, OUTPUT);
  pinMode(LED_AMARILLO, OUTPUT);
  pinMode(LED_VERDE, OUTPUT);
  pinMode(BUZZER_PIN, OUTPUT);

  digitalWrite(LED_ROJO, LOW);
  digitalWrite(LED_AMARILLO, HIGH); // Amarillo = Conectando
  digitalWrite(LED_VERDE, LOW);
  digitalWrite(BUZZER_PIN, LOW);

  // Pantalla OLED SH1106
  if (!display.begin(0x3C, true)) {
    Serial.println("Error al iniciar OLED SH1106");
  }
  display.clearDisplay();
  display.setTextColor(SH110X_WHITE);
  display.setTextSize(1);
  display.setCursor(0, 2);
  display.println("MONITOREO AULA - BLYNK");
  display.setCursor(0, 22);
  display.println("Conectando a red...");
  display.display();

  dht.begin();

  // Configuración de red con WiFiManager
  WiFi.mode(WIFI_STA);
  WiFi.setAutoReconnect(true); 
  WiFi.setSleep(false);

  WiFiManager wm;
  if (!wm.autoConnect("Alarma-Aula-Juanes")) {
    Serial.println("Tiempo agotado. Reiniciando...");
    ESP.restart();
  }

  digitalWrite(LED_AMARILLO, LOW);
  digitalWrite(LED_VERDE, HIGH);

  // Configurar cliente Blynk
  Blynk.config(BLYNK_AUTH_TOKEN);

  // Enviar telemetría cada 2.5 segundos
  timer.setInterval(2500L, enviarTelemetriaBlynk);
}

void loop() {
  if (WiFi.status() == WL_CONNECTED) {
    Blynk.run();
  }
  timer.run();

  unsigned long now = millis();

  // 1. Detección e informe instantáneo del sensor de calor
  bool estadoFuegoActual = (digitalRead(SENSOR_CALOR) == LOW);

  if (estadoFuegoActual) {
    digitalWrite(LED_ROJO, HIGH);
    digitalWrite(LED_VERDE, LOW);
  } else {
    digitalWrite(LED_ROJO, LOW);
    if (WiFi.status() == WL_CONNECTED) {
      digitalWrite(LED_VERDE, HIGH);
      digitalWrite(LED_AMARILLO, LOW);
    }
  }

  // Enviar a Blynk INSTANTÁNEAMENTE cuando el sensor cambie (0 -> 1 o 1 -> 0)
  if (estadoFuegoActual != ultimoEstadoFuego) {
    ultimoEstadoFuego = estadoFuegoActual;
    Blynk.virtualWrite(V2, estadoFuegoActual ? 1 : 0);
    Serial.print("Blynk enviado -> Calor: ");
    Serial.println(estadoFuegoActual ? 1 : 0);
  }

  // 2. Navegación OLED con BOTÓN FÍSICO
  bool lecturaBoton = digitalRead(BOTON_PIN);
  if (lecturaBoton == LOW && ultimoEstadoBoton == HIGH) {
    vistaOled++;
    if (vistaOled > 3) vistaOled = 1;
    delay(30); 
  }
  ultimoEstadoBoton = lecturaBoton;

  // 3. Refresco fluido de Pantalla OLED (cada 100 ms)
  if (now - lastOled > 100) {
    lastOled = now;
    float temp = dht.readTemperature();
    float hum = dht.readHumidity();
    actualizarPantalla(estadoFuegoActual, temp, hum);
  }
}

// ==========================================
// CONTROL Y LECTURA DE PINES VIRTUALES BLYNK
// ==========================================

// Switch para encender/apagar LED Rojo remotamente
BLYNK_WRITE(V5) { 
  int val = param.asInt();
  digitalWrite(LED_ROJO, val ? HIGH : LOW);
}

// Switch para activar/desactivar Buzzer remotamente
BLYNK_WRITE(V6) { 
  int val = param.asInt();
  digitalWrite(BUZZER_PIN, val ? HIGH : LOW);
}

// Botón "Cambiar Pantalla" para rotar vistas del OLED
BLYNK_WRITE(V7) { 
  int val = param.asInt();
  if (val == 1) { // Al presionar el botón en la app
    vistaOled++;
    if (vistaOled > 3) vistaOled = 1;
  }
}

// Envío periódico a Blynk
void enviarTelemetriaBlynk() {
  float temp = dht.readTemperature();
  float hum = dht.readHumidity();

  if (!isnan(temp)) Blynk.virtualWrite(V0, temp);
  if (!isnan(hum))  Blynk.virtualWrite(V1, hum);

  // Diagnóstico de red
  if (Blynk.connected()) {
    Blynk.virtualWrite(V3, WiFi.localIP().toString());
    Blynk.virtualWrite(V4, "Conectado a Blynk");
  }
}

// Sincronización automática al conectar a Blynk
BLYNK_CONNECTED() {
  Blynk.virtualWrite(V3, WiFi.localIP().toString());
  Blynk.virtualWrite(V4, "Conectado a Blynk");
  Blynk.virtualWrite(V2, ultimoEstadoFuego ? 1 : 0);
}

void actualizarPantalla(bool fuego, float temp, float hum) {
  display.clearDisplay();
  display.setTextColor(SH110X_WHITE);
  display.setTextSize(1);

  if (vistaOled == 1) {
    display.setCursor(0, 2);
    display.println("MONITOREO CON BLYNK");

    display.setCursor(0, 18);
    display.print("WiFi: ");
    display.println(WiFi.status() == WL_CONNECTED ? WiFi.SSID() : "Reconectando");

    display.setCursor(0, 34);
    display.print("IP: ");
    display.println(WiFi.status() == WL_CONNECTED ? WiFi.localIP().toString() : "0.0.0.0");

    display.setCursor(0, 50);
    display.print("Blynk: ");
    display.println(Blynk.connected() ? "Conectado" : "Desconectado");

  } else if (vistaOled == 2) {
    display.setCursor(0, 2);
    display.println("SENSOR TEMPERATURA");

    display.setCursor(0, 24);
    display.print("Temp: ");
    display.print(isnan(temp) ? 0.0 : temp, 1);
    display.println(" C");

    display.setCursor(0, 44);
    display.print("Humedad: ");
    display.print(isnan(hum) ? 0.0 : hum, 1);
    display.println(" %");

  } else if (vistaOled == 3) {
    display.setCursor(0, 2);
    display.println("SENSOR DE CALOR");

    display.setCursor(0, 24);
    display.print("Estado: ");
    if (fuego) {
      display.println("!! CALOR !!");
      display.setCursor(0, 44);
      display.println("Alerta Activada");
    } else {
      display.println("NORMAL");
      display.setCursor(0, 44);
      display.println("Sin radiacion");
    }
  }

  display.display();
}





