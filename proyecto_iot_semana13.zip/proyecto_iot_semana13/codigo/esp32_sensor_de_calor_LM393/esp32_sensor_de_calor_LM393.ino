/*
  ===================================================================
  CÓDIGO DE PRUEBA INDIVIDUAL: SENSOR DE CALOR / FUEGO (LM393)
  ===================================================================
  Componente: Sensor Digital de Llama / Calor LM393
  Pin Conectado: GPIO 22 del ESP32
  Lógica: 
    - LOW (0)  -> Calor / Fuego Detectado (Alerta)
    - HIGH (1) -> Estado Normal (Sin radiación de calor)
*/

#define SENSOR_CALOR 22  // Pin digital donde está conectado el LM393
#define LED_ROJO     18  // Pin del LED para indicación local

void setup() {
  // Inicialización de la comunicación serial a 115200 baudios
  Serial.begin(115200);
  
  // Configuración de pines
  pinMode(SENSOR_CALOR, INPUT);
  pinMode(LED_ROJO, OUTPUT);

  digitalWrite(LED_ROJO, LOW);
  Serial.println("--- PRUEBA INDIVIDUAL DEL SENSOR DE CALOR LM393 INICIADA ---");
}

void loop() {
  // Lectura del estado digital del sensor
  int lecturaCalor = digitalRead(SENSOR_CALOR);

  // Verificación de umbral (el módulo activa la salida DO en LOW al detectar calor)
  if (lecturaCalor == LOW) {
    digitalWrite(LED_ROJO, HIGH);
    Serial.println("🔥 ¡ALERTA! Radiación de calor/fuego DETECTADA en GPIO 22.");
  } else {
    digitalWrite(LED_ROJO, LOW);
    Serial.println("✅ Estado Normal: No se detecta presencia de calor.");
  }

  // Pausa de 500 ms entre lecturas para visualización limpia en Monitor Serial
  delay(500);
}